﻿namespace AspNetMvc.Models
{
    public class UpdateResultViewModel
    {
    }
}
