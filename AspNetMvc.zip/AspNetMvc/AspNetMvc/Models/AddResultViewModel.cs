﻿using System.ComponentModel.DataAnnotations;

namespace AspNetMvc.Models
{
    public class AddResultViewModel
    {
        public int ResultId { get; set; }
        public int StudentId { get; set; }
        public int SubjectId { get; set; }

        [Range(0, 100)]
        public int Marks { get; set; }
    }
}
