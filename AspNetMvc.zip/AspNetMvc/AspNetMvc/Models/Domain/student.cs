﻿using System.ComponentModel.DataAnnotations;

namespace AspNetMvc.Models.Domain
{
    public class student
    {
        [Key]
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int Age { get; set; }
        public string City { get; set; }
        public string ContactNo { get; set; }
    }
}

