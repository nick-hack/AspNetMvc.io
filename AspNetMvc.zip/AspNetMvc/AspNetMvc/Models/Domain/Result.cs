﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace AspNetMvc.Models.Domain
{
    public class Result
    {
        [Key]
        public int ResultId { get; set; }

        [ForeignKey("Student")]
        public int StudentId { get; set; }
        public student Student { get; set; }

        [ForeignKey("Subject")]
        public int SubjectId { get; set; }
        public Subject Subject { get; set; }

        [Range(0, 100)]
        public int Marks { get; set; }
    }
}
