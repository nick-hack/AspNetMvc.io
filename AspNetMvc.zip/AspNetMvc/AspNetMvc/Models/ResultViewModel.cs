﻿namespace AspNetMvc.Models
{
    public class ResultViewModel
    {
        public int ResultId { get; set; }
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public string SubjectName { get; set; }
        public int Marks { get; set; }
    }


}
