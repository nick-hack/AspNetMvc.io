﻿namespace AspNetMvc.Models
{
    public class UpdateSubjectViewModel
    {
        public int SubjectId { get; set; }
        public string SubjectName { get; set; }
    }
}
