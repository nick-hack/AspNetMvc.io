﻿namespace AspNetMvc.Models
{
    public class SubjectViewModel
    {
        public string SubjectName { get; set; }
    }
}
