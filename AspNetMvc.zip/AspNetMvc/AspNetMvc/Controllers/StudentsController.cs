﻿using Microsoft.AspNetCore.Mvc;
using AspNetMvc.Models;
using AspNetMvc.Models.Domain;
using AspNetMvc.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace AspNetMvc.Controllers
{
    public class StudentsController : Controller
    {
        private readonly MvcDemoDbcontext mvcDemoDbcontext;

        public StudentsController(MvcDemoDbcontext mvcDemoDbcontext)
        {
            this.mvcDemoDbcontext = mvcDemoDbcontext;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var students = await mvcDemoDbcontext.Students.ToListAsync();
            return View(students);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddStudentViewModel addStudentRequest)
        {
            var student = new student()
            {
                StudentName = addStudentRequest.StudentName,
                Age = addStudentRequest.Age,
                City = addStudentRequest.City,
                ContactNo = addStudentRequest.ContactNo
            };

            await mvcDemoDbcontext.Students.AddAsync(student);
            await mvcDemoDbcontext.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> View(int StudentId)
        {
            var student = await mvcDemoDbcontext.Students.FirstOrDefaultAsync(x => x.StudentId == StudentId);

            if (student != null)
            {
                var viewModel = new UpdateStudentViewModel()
                {
                    StudentId = StudentId,
                    StudentName = student.StudentName,
                    Age = student.Age,
                    City = student.City,
                    ContactNo = student.ContactNo
                };
                return await Task.Run(() =>View("View",viewModel));
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult>View(UpdateStudentViewModel updateStudentViewModel)
        {
            var student = await mvcDemoDbcontext.Students.FindAsync(updateStudentViewModel.StudentId);
            if(student !=null)
            {
                student.StudentName= updateStudentViewModel.StudentName;
                student.Age= updateStudentViewModel.Age;
                student.City= updateStudentViewModel.City;
                student.ContactNo= updateStudentViewModel.ContactNo;

                await mvcDemoDbcontext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");

        }

        [HttpPost]
        public async Task<IActionResult>Delete(UpdateStudentViewModel updateStudentViewModel)
        {
            var student = await mvcDemoDbcontext.Students.FindAsync(updateStudentViewModel.StudentId);

            if(student !=null)
            {
                mvcDemoDbcontext.Students.Remove(student);
                await mvcDemoDbcontext.SaveChangesAsync(); 
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");

        }


    }
}
