﻿using AspNetMvc.Data;
using AspNetMvc.Models;
using AspNetMvc.Models.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AspNetMvc.Controllers
{
    public class SubjectController : Controller
    {
        private readonly MvcDemoDbcontext mvcDemoDbcontext;

        public SubjectController(MvcDemoDbcontext mvcDemoDbcontext)
        {
            this.mvcDemoDbcontext = mvcDemoDbcontext;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var subject = await mvcDemoDbcontext.Subjects.ToListAsync();
            return View(subject);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(SubjectViewModel subjectViewModel)
        {
            var subject = new Subject()
            {
                SubjectName = subjectViewModel.SubjectName,
            };

            await mvcDemoDbcontext.Subjects.AddAsync(subject);
            await mvcDemoDbcontext.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> View(int SubjectId)
        {
            var Subject = await mvcDemoDbcontext.Subjects.FirstOrDefaultAsync(x => x.SubjectId == SubjectId);

            if (Subject != null)
            {
                var viewModel = new UpdateSubjectViewModel()
                {
                    SubjectId = SubjectId,
                    SubjectName = Subject.SubjectName
             
                };
                return await Task.Run(() => View("View", viewModel));
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public async Task<IActionResult> View(UpdateSubjectViewModel updateSubjectViewModel)
        {
            var Subject = await mvcDemoDbcontext.Subjects.FindAsync(updateSubjectViewModel.SubjectId);
            if (Subject != null)
            {
                Subject.SubjectName = updateSubjectViewModel.SubjectName;
       
                await mvcDemoDbcontext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");

        }

        [HttpPost]
        public async Task<IActionResult> Delete(UpdateSubjectViewModel updateSubjectViewModel)
        {
            var subject = await mvcDemoDbcontext.Subjects.FindAsync(updateSubjectViewModel.SubjectId);

            if (subject != null)
            {
                mvcDemoDbcontext.Subjects.Remove(subject);
                await mvcDemoDbcontext.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");

        }
    }
}
