﻿using AspNetMvc.Data;
using AspNetMvc.Models;
using AspNetMvc.Models.Domain;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AspNetMvc.Controllers
{
    public class ResultController : Controller
    {
        private readonly MvcDemoDbcontext mvcDemoDbcontext;

        public ResultController(MvcDemoDbcontext mvcDemoDbcontext)
        {
            this.mvcDemoDbcontext = mvcDemoDbcontext;
        }

        [HttpGet]
        public async Task<IActionResult> Index(int? studentId)
        {
            List<Result> results;
            if (studentId.HasValue)
            {
                results = await mvcDemoDbcontext.Results
                    .Include(r => r.Student)
                    .Include(r => r.Subject)
                    .Where(r => r.StudentId == studentId.Value)
                    .ToListAsync();
            }
            else
            {
                results = await mvcDemoDbcontext.Results
                    .Include(r => r.Student)
                    .Include(r => r.Subject)
                    .ToListAsync();
            }

            var resultViewModels = results.Select(r => new ResultViewModel
            {
                ResultId = r.ResultId,
                StudentId = r.StudentId,
                StudentName = r.Student.StudentName,
                SubjectName = r.Subject.SubjectName,
                Marks = r.Marks
            }).ToList();

            return View(resultViewModels);
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddResultViewModel addResultViewModel)
        {
            var Result = new Result()
            {
                ResultId=addResultViewModel.ResultId,
                StudentId=addResultViewModel.StudentId,
                SubjectId=addResultViewModel.SubjectId,
                Marks = addResultViewModel.Marks

            };

            await mvcDemoDbcontext.Results.AddAsync(Result);
            await mvcDemoDbcontext.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        //[HttpGet]
        //public async Task<IActionResult> View(int ResultId)
        //{
        //    var Results = await mvcDemoDbcontext.Results.FirstOrDefaultAsync(x => x.ResultId == ResultId);

        //    if (Results != null)
        //    {
        //        var viewModel = new UpdateStudentViewModel()
        //        {
        //            StudentId = StudentId,
        //            StudentName = student.StudentName,
        //            Age = student.Age,
        //            City = student.City,
        //            ContactNo = student.ContactNo
        //        };
        //        return await Task.Run(() => View("View", viewModel));
        //    }

        //    return RedirectToAction("Index");
        //}

        //[HttpPost]
        //public async Task<IActionResult> View(UpdateStudentViewModel updateStudentViewModel)
        //{
        //    var student = await mvcDemoDbcontext.Students.FindAsync(updateStudentViewModel.StudentId);
        //    if (student != null)
        //    {
        //        student.StudentName = updateStudentViewModel.StudentName;
        //        student.Age = updateStudentViewModel.Age;
        //        student.City = updateStudentViewModel.City;
        //        student.ContactNo = updateStudentViewModel.ContactNo;

        //        await mvcDemoDbcontext.SaveChangesAsync();
        //        return RedirectToAction("Index");
        //    }
        //    return RedirectToAction("Index");

        //}

        //[HttpPost]
        //public async Task<IActionResult> Delete(UpdateStudentViewModel updateStudentViewModel)
        //{
        //    var student = await mvcDemoDbcontext.Students.FindAsync(updateStudentViewModel.StudentId);

        //    if (student != null)
        //    {
        //        mvcDemoDbcontext.Students.Remove(student);
        //        await mvcDemoDbcontext.SaveChangesAsync();
        //        return RedirectToAction("Index");
        //    }
        //    return RedirectToAction("Index");

        //}

    }
}
