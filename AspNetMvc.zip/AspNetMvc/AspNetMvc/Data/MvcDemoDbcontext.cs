﻿using AspNetMvc.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace AspNetMvc.Data
{
    public class MvcDemoDbcontext : DbContext
    {
        public MvcDemoDbcontext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<student> Students { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<Result> Results { get; set; }
    }
}
